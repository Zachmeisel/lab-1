#pragma once

namespace lab_1_1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		Graphics^ g;
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  Hide;
	protected:

	protected:

	private: System::Windows::Forms::PictureBox^  picture;








	protected:


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->Hide = (gcnew System::Windows::Forms::Button());
			this->picture = (gcnew System::Windows::Forms::PictureBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->picture))->BeginInit();
			this->SuspendLayout();
			// 
			// Hide
			// 
			this->Hide->Location = System::Drawing::Point(239, 399);
			this->Hide->Name = L"Hide";
			this->Hide->Size = System::Drawing::Size(75, 23);
			this->Hide->TabIndex = 1;
			this->Hide->Text = L"Show";
			this->Hide->UseVisualStyleBackColor = true;
			this->Hide->Click += gcnew System::EventHandler(this, &MyForm::Hide_Click);
			// 
			// picture
			// 
			this->picture->Location = System::Drawing::Point(57, 37);
			this->picture->Name = L"picture";
			this->picture->Size = System::Drawing::Size(461, 342);
			this->picture->TabIndex = 2;
			this->picture->TabStop = false;
			this->picture->Click += gcnew System::EventHandler(this, &MyForm::pictureBox1_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(580, 464);
			this->Controls->Add(this->picture);
			this->Controls->Add(this->Hide);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->picture))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion
		bool a = false;
		
	private: System::Void Hide_Click(System::Object^  sender, System::EventArgs^  e) {
		a = !a;
		
		if (a == true)
	{
		picture->Visible = true;
		Hide->Text = "Hide";
		
		g = picture->CreateGraphics();
		Bitmap^ bmp = gcnew Bitmap(L"badger.bmp");
		TextureBrush tBrush(bmp);
		g->DrawImage(bmp, 0, 0);
	}
	else
	{
		Hide->Text = "Show";
		picture->Refresh();

	}

		
		
		
		

	}
	
		
	private: System::Void pictureBox1_Click(System::Object^  sender, System::EventArgs^  e) {
		
		
			
	}
	private: System::Void MyForm_Load(System::Object^  sender, System::EventArgs^  e) {
		
		

	}
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
		
		
}
private: System::Void Load_Click(System::Object^  sender, System::EventArgs^  e) {
	

		
}
};
}
